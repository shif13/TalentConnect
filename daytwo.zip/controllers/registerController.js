const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { db } = require('../config/db');
const { cleanupUploadedFiles } = require('../middleware/registerMiddleware');

// Import the email service (make sure this file exists or comment out if not using)
const { sendWelcomeEmail } = require('../services/emailService');

// Create tables if they don't exist
const createTables = () => {
  return new Promise((resolve, reject) => {
    // Users table - Add resetToken and resetTokenExpiry columns
    const createUsersTable = `
      CREATE TABLE IF NOT EXISTS users (
        id INT PRIMARY KEY AUTO_INCREMENT,
        userName VARCHAR(50) UNIQUE NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        userType ENUM('jobseeker', 'recruiter') NOT NULL,
        firstName VARCHAR(50) NOT NULL,
        lastName VARCHAR(50) NOT NULL,
        phone VARCHAR(20),
        location VARCHAR(100),
        resetToken VARCHAR(255),
        resetTokenExpiry DATETIME,
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `;

    // Job seekers profile table
    const createJobSeekersTable = `
      CREATE TABLE IF NOT EXISTS job_seekers (
        id INT PRIMARY KEY AUTO_INCREMENT,
        userId INT NOT NULL,
        title VARCHAR(100),
        experience VARCHAR(50),
        skills JSON,
        expectedSalary VARCHAR(50),
        linkedinUrl VARCHAR(255),
        githubUrl VARCHAR(255),
        bio TEXT,
        availability ENUM('available', 'busy') DEFAULT 'available',
        cvFilePath VARCHAR(255),
        certificatesPath JSON,
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
      )
    `;

    // Execute table creation queries in sequence
    db.query(createUsersTable, (err) => {
      if (err) {
        console.error('Error creating users table:', err.message);
        return reject(err);
      }
      
      db.query(createJobSeekersTable, (err) => {
        if (err) {
          console.error('Error creating job_seekers table:', err.message);
          return reject(err);
        }
    
      });
    });
  });
};

// Initialize tables on first controller load
let tablesInitialized = false;
const initializeTables = async () => {
  if (!tablesInitialized) {
    try {
      await createTables();
      tablesInitialized = true;
    } catch (error) {
      console.error('Failed to initialize tables:', error);
    }
  }
};

// Call initialization
initializeTables();

// Helper function to safely parse JSON
const safeJsonParse = (jsonString, fallback = []) => {
  if (!jsonString) return fallback;
  if (typeof jsonString !== 'string') return jsonString;
  
  try {
    const parsed = JSON.parse(jsonString);
    return Array.isArray(parsed) ? parsed : fallback;
  } catch (error) {
    console.warn('JSON parse error for:', jsonString, error.message);
    return fallback;
  }
};

// Helper function to validate and process skills
const processSkills = (skills) => {
  console.log('Processing skills - input:', { type: typeof skills, value: skills });
  
  let skillsArray = [];
  
  if (!skills) {
    return skillsArray;
  }
  
  // If it's already an array, use it
  if (Array.isArray(skills)) {
    skillsArray = skills;
  }
  // If it's a string, try to parse as JSON first, then fallback to comma-split
  else if (typeof skills === 'string') {
    const trimmed = skills.trim();
    
    if (trimmed === '' || trimmed === '[]') {
      return skillsArray;
    }
    
    // Try JSON parse first
    if (trimmed.startsWith('[') && trimmed.endsWith(']')) {
      try {
        const parsed = JSON.parse(trimmed);
        if (Array.isArray(parsed)) {
          skillsArray = parsed;
        }
      } catch (jsonError) {
        console.warn('Failed to parse skills JSON:', jsonError.message);
        // Fallback to comma-split
        skillsArray = trimmed.split(',').map(s => s.trim()).filter(s => s.length > 0);
      }
    } else {
      // Split by comma
      skillsArray = trimmed.split(',').map(s => s.trim()).filter(s => s.length > 0);
    }
  }
  
  // Clean and validate the array
  skillsArray = skillsArray
    .map(skill => String(skill).trim())
    .filter(skill => skill.length > 0 && skill.length <= 50)
    .slice(0, 20); // Limit to 20 skills
  
  console.log('Processed skills result:', skillsArray);
  return skillsArray;
};

const registerUser = async (req, res) => {
  try {
    console.log('=== REGISTRATION REQUEST DEBUG ===');
    console.log('Method:', req.method);
    console.log('Content-Type:', req.headers['content-type']);
    console.log('Body keys:', Object.keys(req.body || {}));
    console.log('Files keys:', req.files ? Object.keys(req.files) : 'No files');
    
    // Log specific fields
    console.log('Key fields check:');
    console.log('firstName:', req.body.firstName);
    console.log('lastName:', req.body.lastName);
    console.log('userName:', req.body.userName);
    console.log('email:', req.body.email);
    console.log('userType:', req.body.userType);
    console.log('skills raw:', req.body.skills);

    const {
      userName,
      email,
      password,
      userType,
      firstName,
      lastName,
      phone,
      location,
      // Job seeker fields
      title,
      experience,
      skills,
      expectedSalary,
      linkedinUrl,
      githubUrl,
      bio,
      availability,
      // Recruiter fields
      companyName,
      companySize,
      industry,
      companyWebsite,
      companyDescription,
      position
    } = req.body;

    // Validate required fields first
    if (!firstName || !lastName || !userName || !email || !password || !userType) {
      console.log('Missing required fields:', {
        firstName: !!firstName,
        lastName: !!lastName,
        userName: !!userName,
        email: !!email,
        password: !!password,
        userType: !!userType
      });
      
      cleanupUploadedFiles(req);
      return res.status(400).json({ 
        success: false, 
        msg: 'Please provide all required fields: firstName, lastName, userName, email, password, userType' 
      });
    }

    // Validate user type
    if (!['jobseeker', 'recruiter'].includes(userType)) {
      cleanupUploadedFiles(req);
      return res.status(400).json({ 
        success: false, 
        msg: 'Invalid user type. Must be either "jobseeker" or "recruiter"' 
      });
    }

    // Additional validation for recruiters
    if (userType === 'recruiter' && (!companyName || companyName.trim().length < 2)) {
      cleanupUploadedFiles(req);
      return res.status(400).json({ 
        success: false, 
        msg: 'Company name is required for recruiters and must be at least 2 characters' 
      });
    }

    // Validate field lengths and formats
    if (firstName.trim().length < 1 || firstName.trim().length > 50) {
      cleanupUploadedFiles(req);
      return res.status(400).json({ 
        success: false, 
        msg: 'First name must be between 1-50 characters' 
      });
    }

    if (lastName.trim().length < 1 || lastName.trim().length > 50) {
      cleanupUploadedFiles(req);
      return res.status(400).json({ 
        success: false, 
        msg: 'Last name must be between 1-50 characters' 
      });
    }

    if (userName.trim().length < 3 || userName.trim().length > 30) {
      cleanupUploadedFiles(req);
      return res.status(400).json({ 
        success: false, 
        msg: 'Username must be between 3-30 characters' 
      });
    }

    if (password.length < 6) {
      cleanupUploadedFiles(req);
      return res.status(400).json({ 
        success: false, 
        msg: 'Password must be at least 6 characters long' 
      });
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      cleanupUploadedFiles(req);
      return res.status(400).json({ 
        success: false, 
        msg: 'Please provide a valid email address' 
      });
    }

    // Validate username format
    const usernameRegex = /^[a-zA-Z0-9_]{3,30}$/;
    if (!usernameRegex.test(userName.trim())) {
      cleanupUploadedFiles(req);
      return res.status(400).json({ 
        success: false, 
        msg: 'Username can only contain letters, numbers, and underscores' 
      });
    }

    console.log('All validations passed, checking for existing users...');

    // Check if user already exists
    const checkUserQuery = 'SELECT id, email, userName FROM users WHERE email = ? OR userName = ?';
    
    db.query(checkUserQuery, [email.toLowerCase().trim(), userName.trim()], async (err, existingUsers) => {
      if (err) {
        console.error('Database error during user check:', err);
        cleanupUploadedFiles(req);
        return res.status(500).json({ 
          success: false, 
          msg: 'Database error. Please try again.' 
        });
      }

      if (existingUsers.length > 0) {
        const existingUser = existingUsers[0];
        let conflictField = 'email or username';
        if (existingUser.email === email.toLowerCase().trim()) {
          conflictField = 'email';
        } else if (existingUser.userName === userName.trim()) {
          conflictField = 'username';
        }
        
        console.log('User already exists:', conflictField);
        cleanupUploadedFiles(req);
        return res.status(409).json({ 
          success: false, 
          msg: `User with this ${conflictField} already exists` 
        });
      }

      try {
        console.log('Creating new user...');
        
        // Hash password
        const saltRounds = 12;
        const hashedPassword = await bcrypt.hash(password, saltRounds);

        // Insert user into users table
        const insertUserQuery = `
          INSERT INTO users (userName, email, password, userType, firstName, lastName, phone, location) 
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `;
        
        const userValues = [
          userName.trim(),
          email.toLowerCase().trim(),
          hashedPassword,
          userType,
          firstName.trim(),
          lastName.trim(),
          phone ? phone.trim() : null,
          location ? location.trim() : null
        ];

        db.query(insertUserQuery, userValues, async (err, userResult) => {
          if (err) {
            console.error('User insertion error:', err);
            cleanupUploadedFiles(req);
            
            // Handle specific MySQL errors
            if (err.code === 'ER_DUP_ENTRY') {
              return res.status(409).json({ 
                success: false, 
                msg: 'User with this email or username already exists' 
              });
            }
            
            return res.status(500).json({ 
              success: false, 
              msg: 'Database error during user creation. Please try again.' 
            });
          }

          const userId = userResult.insertId;
          console.log('User created with ID:', userId);
          
          // Prepare user data for response and email
          const userData = {
            id: userId,
            firstName: firstName.trim(),
            lastName: lastName.trim(),
            userName: userName.trim(),
            email: email.toLowerCase().trim(),
            userType
          };

          if (userType === 'jobseeker') {
            await handleJobSeekerRegistration(req, res, userId, userData);
          } else if (userType === 'recruiter') {
            await handleRecruiterRegistration(req, res, userId, userData, companyName);
          }
        });

      } catch (hashError) {
        console.error('Password hashing error:', hashError);
        cleanupUploadedFiles(req);
        res.status(500).json({ 
          success: false, 
          msg: 'Server error during password processing. Please try again.' 
        });
      }
    });

  } catch (error) {
    console.error('Registration error:', error);
    cleanupUploadedFiles(req);
    res.status(500).json({ 
      success: false, 
      msg: 'Server error during registration. Please try again.' 
    });
  }
};

// Handle job seeker registration
const handleJobSeekerRegistration = async (req, res, userId, userData) => {
  try {
    console.log('Processing job seeker registration...');
    
    const {
      title,
      experience,
      skills,
      expectedSalary,
      linkedinUrl,
      githubUrl,
      bio,
      availability
    } = req.body;

    // Handle file uploads
    let cvFilePath = null;
    let certificatesPath = [];

    if (req.files) {
      // Handle CV file
      if (req.files.cvFile && req.files.cvFile[0]) {
        cvFilePath = req.files.cvFile[0].path;
        console.log('CV file uploaded:', req.files.cvFile[0].filename);
      }

      // Handle certificate files
      if (req.files.certificateFiles && req.files.certificateFiles.length > 0) {
        certificatesPath = req.files.certificateFiles.map(file => file.path);
        console.log('Certificate files uploaded:', req.files.certificateFiles.length);
      }
    }

    // Process skills using the helper function
    const parsedSkills = processSkills(skills);

    // Validate URLs
    const validateUrl = (url) => {
      if (!url || url.trim() === '') return null;
      try {
        const urlObj = new URL(url.trim());
        return urlObj.protocol === 'http:' || urlObj.protocol === 'https:' ? url.trim() : null;
      } catch {
        return null;
      }
    };

    const validLinkedinUrl = validateUrl(linkedinUrl);
    const validGithubUrl = validateUrl(githubUrl);

    // Insert job seeker profile
    const insertJobSeekerQuery = `
      INSERT INTO job_seekers (
        userId, title, experience, skills, expectedSalary, 
        linkedinUrl, githubUrl, bio, availability, cvFilePath, certificatesPath
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    
    const jobSeekerValues = [
      userId,
      title ? title.trim() : null,
      experience ? experience.trim() : null,
      JSON.stringify(parsedSkills),
      expectedSalary ? expectedSalary.trim() : null,
      validLinkedinUrl,
      validGithubUrl,
      bio ? bio.trim() : null,
      availability || 'available',
      cvFilePath,
      JSON.stringify(certificatesPath)
    ];

    console.log('Inserting job seeker profile with values:', jobSeekerValues);

    db.query(insertJobSeekerQuery, jobSeekerValues, async (err) => {
      if (err) {
        console.error('Job seeker profile insertion error:', err);
        cleanupUploadedFiles(req);
        return res.status(500).json({ 
          success: false, 
          msg: 'Error creating job seeker profile. Please try again.' 
        });
      }

      console.log('Job seeker profile created successfully');

      // Generate JWT token
      const token = generateJWTToken(userId, userData.email, userData.userType);

      // Send welcome email (non-blocking)
      sendWelcomeEmailAsync(userData, 'jobseeker');

      // Send success response
      res.status(201).json({
        success: true,
        msg: 'Registration successful! Welcome to TalentConnect!',
        token,
        user: {
          id: userId,
          userName: userData.userName,
          email: userData.email,
          userType: userData.userType,
          firstName: userData.firstName,
          lastName: userData.lastName
        }
      });
    });

  } catch (error) {
    console.error('Job seeker registration error:', error);
    cleanupUploadedFiles(req);
    res.status(500).json({ 
      success: false, 
      msg: 'Error during job seeker registration. Please try again.' 
    });
  }
};

// Handle recruiter registration
const handleRecruiterRegistration = async (req, res, userId, userData, companyName) => {
  try {
    console.log('Processing recruiter registration...');
    
    const {
      companySize,
      industry,
      companyWebsite,
      companyDescription,
      position
    } = req.body;

    // Validate company website URL
    const validateUrl = (url) => {
      if (!url || url.trim() === '') return null;
      try {
        const urlObj = new URL(url.trim());
        return urlObj.protocol === 'http:' || urlObj.protocol === 'https:' ? url.trim() : null;
      } catch {
        return null;
      }
    };

    const validWebsite = validateUrl(companyWebsite);

    // Insert recruiter profile
    const insertRecruiterQuery = `
      INSERT INTO recruiters (
        userId, companyName, companySize, industry, 
        companyWebsite, companyDescription, position
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    
    const recruiterValues = [
      userId,
      companyName.trim(),
      companySize ? companySize.trim() : null,
      industry ? industry.trim() : null,
      validWebsite,
      companyDescription ? companyDescription.trim() : null,
      position ? position.trim() : null
    ];

    console.log('Inserting recruiter profile with values:', recruiterValues);

    db.query(insertRecruiterQuery, recruiterValues, async (err) => {
      if (err) {
        console.error('Recruiter profile insertion error:', err);
        return res.status(500).json({ 
          success: false, 
          msg: 'Error creating recruiter profile. Please try again.' 
        });
      }

      console.log('Recruiter profile created successfully');

      // Generate JWT token
      const token = generateJWTToken(userId, userData.email, userData.userType);

      // Send welcome email (non-blocking)
      sendWelcomeEmailAsync(userData, 'recruiter', companyName);

      // Send success response
      res.status(201).json({
        success: true,
        msg: 'Registration successful! Welcome to TalentConnect!',
        token,
        user: {
          id: userId,
          userName: userData.userName,
          email: userData.email,
          userType: userData.userType,
          firstName: userData.firstName,
          lastName: userData.lastName
        }
      });
    });

  } catch (error) {
    console.error('Recruiter registration error:', error);
    res.status(500).json({ 
      success: false, 
      msg: 'Error during recruiter registration. Please try again.' 
    });
  }
};

// Helper function to generate JWT token
const generateJWTToken = (userId, email, userType) => {
  try {
    const payload = {
      userId: userId,
      email: email,
      userType: userType,
      iat: Math.floor(Date.now() / 1000)
    };

    const token = jwt.sign(
      payload,
      process.env.JWT_SECRET || 'your-default-secret-key-change-this',
      { 
        expiresIn: '24h',
        issuer: 'talentconnect'
      }
    );

    return token;
  } catch (error) {
    console.error('Token generation error:', error);
    throw new Error('Failed to generate authentication token');
  }
};

// Helper function to send welcome email asynchronously
const sendWelcomeEmailAsync = async (userData, userType, companyName = null) => {
  try {
    const emailResult = await sendWelcomeEmail(userData, userType, companyName);
    if (emailResult.success) {
      console.log(`Welcome email sent successfully to ${userType}:`, userData.email);
    } else {
      console.warn(`Failed to send welcome email to ${userType}:`, emailResult.error);
    }
  } catch (emailError) {
    console.warn('Email sending error:', emailError.message);
    // Don't fail registration if email fails
  }
};

// Get user profile
const getUserProfile = (req, res) => {
  try {
    const userId = req.user?.userId;

    if (!userId) {
      return res.status(401).json({ 
        success: false, 
        msg: 'Authentication required' 
      });
    }

    const query = `
      SELECT id, userName, email, userType, firstName, lastName, 
             phone, location, createdAt 
      FROM users 
      WHERE id = ?
    `;
    
    db.query(query, [userId], (err, users) => {
      if (err) {
        console.error('Get profile error:', err);
        return res.status(500).json({ 
          success: false, 
          msg: 'Error fetching user profile' 
        });
      }

      if (users.length === 0) {
        return res.status(404).json({ 
          success: false, 
          msg: 'User not found' 
        });
      }

      const user = users[0];

      if (user.userType === 'jobseeker') {
        const profileQuery = 'SELECT * FROM job_seekers WHERE userId = ?';
        
        db.query(profileQuery, [userId], (err, jobSeekers) => {
          if (err) {
            console.error('Job seeker profile error:', err);
            return res.status(500).json({ 
              success: false, 
              msg: 'Error fetching user profile' 
            });
          }

          let profile = null;
          if (jobSeekers.length > 0) {
            try {
              profile = {
                ...jobSeekers[0],
                skills: safeJsonParse(jobSeekers[0].skills, []),
                certificatesPath: safeJsonParse(jobSeekers[0].certificatesPath, [])
              };
            } catch (parseError) {
              console.warn('Error parsing JSON fields:', parseError);
              profile = {
                ...jobSeekers[0],
                skills: [],
                certificatesPath: []
              };
            }
          }

          res.json({
            success: true,
            user,
            profile
          });
        });

      } else if (user.userType === 'recruiter') {
        const profileQuery = 'SELECT * FROM recruiters WHERE userId = ?';
        
        db.query(profileQuery, [userId], (err, recruiters) => {
          if (err) {
            console.error('Recruiter profile error:', err);
            return res.status(500).json({ 
              success: false, 
              msg: 'Error fetching user profile' 
            });
          }

          let profile = null;
          if (recruiters.length > 0) {
            profile = recruiters[0];
          }

          res.json({
            success: true,
            user,
            profile
          });
        });
      } else {
        res.status(400).json({
          success: false,
          msg: 'Invalid user type'
        });
      }
    });
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({ 
      success: false, 
      msg: 'Error fetching user profile' 
    });
  }
};

// Update user profile
const updateUserProfile = async (req, res) => {
  try {
    const userId = req.user?.userId;

    if (!userId) {
      return res.status(401).json({ 
        success: false, 
        msg: 'Authentication required' 
      });
    }

    const { 
      firstName, 
      lastName, 
      userName, 
      email, 
      phone, 
      location,
      // Job seeker fields
      title, 
      experience, 
      skills, 
      expectedSalary, 
      linkedinUrl, 
      githubUrl, 
      bio, 
      availability,
      // Recruiter fields
      companyName,
      companySize,
      industry,
      companyWebsite,
      companyDescription,
      position
    } = req.body;

    // Validate required fields
    if (!firstName || !lastName || !userName || !email) {
      return res.status(400).json({
        success: false,
        msg: 'First name, last name, username, and email are required'
      });
    }

    // Update users table
    const updateUserQuery = `
      UPDATE users 
      SET firstName = ?, lastName = ?, userName = ?, email = ?, phone = ?, location = ? 
      WHERE id = ?
    `;
    
    const userValues = [
      firstName.trim(),
      lastName.trim(),
      userName.trim(),
      email.toLowerCase().trim(),
      phone ? phone.trim() : null,
      location ? location.trim() : null,
      userId
    ];
    
    db.query(updateUserQuery, userValues, (err) => {
      if (err) {
        console.error('User update error:', err);
        
        if (err.code === 'ER_DUP_ENTRY') {
          return res.status(409).json({ 
            success: false, 
            msg: 'Username or email already exists' 
          });
        }
        
        return res.status(500).json({ 
          success: false, 
          msg: 'Server error during update' 
        });
      }

      // Get user type to update appropriate profile
      const getUserTypeQuery = 'SELECT userType FROM users WHERE id = ?';
      
      db.query(getUserTypeQuery, [userId], (err, users) => {
        if (err) {
          console.error('Get user type error:', err);
          return res.status(500).json({ 
            success: false, 
            msg: 'Server error during update' 
          });
        }

        if (users.length === 0) {
          return res.status(404).json({ 
            success: false, 
            msg: 'User not found' 
          });
        }

        const userType = users[0].userType;

        if (userType === 'jobseeker') {
          updateJobSeekerProfile(req, res, userId, {
            title, experience, skills, expectedSalary, 
            linkedinUrl, githubUrl, bio, availability
          });
        } else if (userType === 'recruiter') {
          updateRecruiterProfile(req, res, userId, {
            companyName, companySize, industry, 
            companyWebsite, companyDescription, position
          });
        } else {
          res.status(400).json({
            success: false,
            msg: 'Invalid user type'
          });
        }
      });
    });
  } catch (error) {
    console.error('Profile update error:', error);
    res.status(500).json({ 
      success: false, 
      msg: 'Server error during update' 
    });
  }
};

// Update job seeker profile
const updateJobSeekerProfile = (req, res, userId, profileData) => {
  const { title, experience, skills, expectedSalary, linkedinUrl, githubUrl, bio, availability } = profileData;

  // Process skills using the helper function
  const parsedSkills = processSkills(skills);

  // Validate URLs
  const validateUrl = (url) => {
    if (!url || url.trim() === '') return null;
    try {
      const urlObj = new URL(url.trim());
      return urlObj.protocol === 'http:' || urlObj.protocol === 'https:' ? url.trim() : null;
    } catch {
      return null;
    }
  };

  const validLinkedinUrl = validateUrl(linkedinUrl);
  const validGithubUrl = validateUrl(githubUrl);

  const updateProfileQuery = `
    UPDATE job_seekers 
    SET title = ?, experience = ?, skills = ?, expectedSalary = ?, 
        linkedinUrl = ?, githubUrl = ?, bio = ?, availability = ?
    WHERE userId = ?
  `;
  
  const values = [
    title ? title.trim() : null, 
    experience ? experience.trim() : null, 
    JSON.stringify(parsedSkills), 
    expectedSalary ? expectedSalary.trim() : null, 
    validLinkedinUrl, 
    validGithubUrl, 
    bio ? bio.trim() : null, 
    availability || 'available', 
    userId
  ];
  
  db.query(updateProfileQuery, values, (err) => {
    if (err) {
      console.error('Job seeker profile update error:', err);
      return res.status(500).json({ 
        success: false, 
        msg: 'Server error during profile update' 
      });
    }

    res.json({ 
      success: true, 
      msg: 'Profile updated successfully' 
    });
  });
};

// Update recruiter profile
const updateRecruiterProfile = (req, res, userId, profileData) => {
  const { companyName, companySize, industry, companyWebsite, companyDescription, position } = profileData;

  // Validate company website URL
  const validateUrl = (url) => {
    if (!url || url.trim() === '') return null;
    try {
      const urlObj = new URL(url.trim());
      return urlObj.protocol === 'http:' || urlObj.protocol === 'https:' ? url.trim() : null;
    } catch {
      return null;
    }
  };

  const validWebsite = validateUrl(companyWebsite);

  const updateRecruiterQuery = `
    UPDATE recruiters 
    SET companyName = ?, companySize = ?, industry = ?, 
        companyWebsite = ?, companyDescription = ?, position = ? 
    WHERE userId = ?
  `;
  
  const values = [
    companyName ? companyName.trim() : null,
    companySize ? companySize.trim() : null,
    industry ? industry.trim() : null,
    validWebsite,
    companyDescription ? companyDescription.trim() : null,
    position ? position.trim() : null,
    userId
  ];
  
  db.query(updateRecruiterQuery, values, (err) => {
    if (err) {
      console.error('Recruiter profile update error:', err);
      return res.status(500).json({ 
        success: false, 
        msg: 'Server error during profile update' 
      });
    }

    res.json({ 
      success: true, 
      msg: 'Profile updated successfully' 
    });
  });
};

module.exports = {
  registerUser,
  getUserProfile,
  updateUserProfile,
  createTables
};