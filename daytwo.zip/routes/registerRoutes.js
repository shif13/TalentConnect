const express = require('express');
const router = express.Router();

// Import controller functions
const {
  registerUser,
  getUserProfile,
  updateUserProfile
} = require('../controllers/registerController');

// Import middleware functions
const {
  uploadFields,
  validateRegistration
} = require('../middleware/registerMiddleware');

// Import auth middleware
const authMiddleware = require('../middleware/authMiddleware');

// Logging middleware for debugging
router.use((req, res, next) => {
    console.log(`Register Route: ${req.method} ${req.originalUrl}`);
    console.log('Content-Type:', req.headers['content-type']);
    next();
});

// Public routes
router.post('/user', uploadFields, validateRegistration, registerUser);

// Protected routes (require authentication)
router.get('/profile', authMiddleware, getUserProfile);
router.put('/profile', authMiddleware, updateUserProfile);

// Test route for debugging
router.get('/test', (req, res) => {
    res.json({
        success: true,
        message: 'Register routes are working',
        timestamp: new Date().toISOString()
    });
});

module.exports = router;