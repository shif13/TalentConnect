const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { db } = require('../config/db');

// Import the email service (make sure this file exists or comment out if not using)
// const { sendWelcomeEmail } = require('../services/emailService');

// Create tables if they don't exist
const createTables = () => {
  return new Promise((resolve, reject) => {
    // Users table - Add resetToken and resetTokenExpiry columns
    const createUsersTable = `
      CREATE TABLE IF NOT EXISTS users (
        id INT PRIMARY KEY AUTO_INCREMENT,
        userName VARCHAR(50) UNIQUE NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        userType ENUM('jobseeker', 'recruiter') NOT NULL,
        firstName VARCHAR(50) NOT NULL,
        lastName VARCHAR(50) NOT NULL,
        phone VARCHAR(20),
        location VARCHAR(100),
        resetToken VARCHAR(255),
        resetTokenExpiry DATETIME,
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `;

    // Job seekers profile table
    const createJobSeekersTable = `
      CREATE TABLE IF NOT EXISTS job_seekers (
        id INT PRIMARY KEY AUTO_INCREMENT,
        userId INT NOT NULL,
        title VARCHAR(100),
        experience VARCHAR(50),
        skills JSON,
        expectedSalary VARCHAR(50),
        linkedinUrl VARCHAR(255),
        githubUrl VARCHAR(255),
        bio TEXT,
        availability ENUM('available', 'busy') DEFAULT 'available',
        cvFilePath VARCHAR(255),
        certificatesPath JSON,
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
      )
    `;

    // Recruiters profile table
    const createRecruitersTable = `
      CREATE TABLE IF NOT EXISTS recruiters (
        id INT PRIMARY KEY AUTO_INCREMENT,
        userId INT NOT NULL,
        companyName VARCHAR(100) NOT NULL,
        companySize VARCHAR(50),
        industry VARCHAR(50),
        companyWebsite VARCHAR(255),
        companyDescription TEXT,
        position VARCHAR(100),
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
      )
    `;

    // Job applications table (for future use)
    const createApplicationsTable = `
      CREATE TABLE IF NOT EXISTS applications (
        id INT PRIMARY KEY AUTO_INCREMENT,
        jobSeekerId INT NOT NULL,
        recruiterId INT NOT NULL,
        status ENUM('pending', 'contacted', 'rejected', 'hired') DEFAULT 'pending',
        message TEXT,
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (jobSeekerId) REFERENCES job_seekers(id) ON DELETE CASCADE,
        FOREIGN KEY (recruiterId) REFERENCES recruiters(id) ON DELETE CASCADE
      )
    `;

    // Execute table creation queries in sequence
    db.query(createUsersTable, (err) => {
      if (err) {
        console.error('Error creating users table:', err.message);
        return reject(err);
      }
      
      db.query(createJobSeekersTable, (err) => {
        if (err) {
          console.error('Error creating job_seekers table:', err.message);
          return reject(err);
        }
        
        db.query(createRecruitersTable, (err) => {
          if (err) {
            console.error('Error creating recruiters table:', err.message);
            return reject(err);
          }
          
          db.query(createApplicationsTable, (err) => {
            if (err) {
              console.error('Error creating applications table:', err.message);
              return reject(err);
            }
            
            console.log('Database tables created successfully');
            resolve(true);
          });
        });
      });
    });
  });
};

// Initialize tables on first controller load
let tablesInitialized = false;
const initializeTables = async () => {
  if (!tablesInitialized) {
    try {
      await createTables();
      tablesInitialized = true;
    } catch (error) {
      console.error('Failed to initialize tables:', error);
    }
  }
};

// Call initialization
initializeTables();

const registerUser = async (req, res) => {
  try {
    const {
      userName,
      email,
      password,
      userType,
      firstName,
      lastName,
      phone,
      location,
      // Job seeker fields
      title,
      experience,
      skills,
      expectedSalary,
      linkedinUrl,
      githubUrl,
      bio,
      availability,
      // Recruiter fields
      companyName,
      companySize,
      industry,
      companyWebsite,
      companyDescription,
      position
    } = req.body;

    console.log('Registration request received:', { userName, email, userType });
    console.log('Skills received:', skills, typeof skills);

    // Validate required fields
    if (!userName || !email || !password || !userType || !firstName || !lastName) {
      return res.status(400).json({ 
        success: false, 
        msg: 'Please provide all required fields' 
      });
    }

    // Validate user type
    if (!['jobseeker', 'recruiter'].includes(userType)) {
      return res.status(400).json({ 
        success: false, 
        msg: 'Invalid user type' 
      });
    }

    // Additional validation for recruiters
    if (userType === 'recruiter' && !companyName) {
      return res.status(400).json({ 
        success: false, 
        msg: 'Company name is required for recruiters' 
      });
    }

    // Check if user already exists
    const checkUserQuery = 'SELECT id FROM users WHERE email = ? OR userName = ?';
    db.query(checkUserQuery, [email, userName], async (err, existingUsers) => {
      if (err) {
        console.error('Database error:', err);
        return res.status(500).json({ 
          success: false, 
          msg: 'Server error during registration' 
        });
      }

      if (existingUsers.length > 0) {
        return res.status(400).json({ 
          success: false, 
          msg: 'User with this email or username already exists' 
        });
      }

      try {
        // Hash password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // Insert user into users table
        const insertUserQuery = `
          INSERT INTO users (userName, email, password, userType, firstName, lastName, phone, location) 
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `;
        
        db.query(insertUserQuery, 
          [userName, email, hashedPassword, userType, firstName, lastName, phone || null, location || null], 
          async (err, userResult) => {
            if (err) {
              console.error('User insertion error:', err);
              return res.status(500).json({ 
                success: false, 
                msg: 'Server error during registration' 
              });
            }

            const userId = userResult.insertId;
            console.log('User created with ID:', userId);
            
            // Prepare user data for email
            const userData = {
              firstName,
              lastName,
              userName,
              email
            };

            if (userType === 'jobseeker') {
              // Handle file uploads
              let cvFilePath = null;
              let certificatesPath = [];

              if (req.files) {
                // Handle CV file
                if (req.files.cvFile && req.files.cvFile[0]) {
                  cvFilePath = req.files.cvFile[0].path;
                }

                // Handle certificate files
                if (req.files.certificateFiles) {
                  certificatesPath = req.files.certificateFiles.map(file => file.path);
                }
              }

              // Parse skills properly
              let parsedSkills = [];
              if (skills) {
                try {
                  // If skills is already a string (JSON), parse it
                  if (typeof skills === 'string') {
                    parsedSkills = JSON.parse(skills);
                  } 
                  // If skills is an array, use it directly
                  else if (Array.isArray(skills)) {
                    parsedSkills = skills;
                  }
                  // If skills is an object or other type, convert to array
                  else {
                    parsedSkills = [];
                  }
                  
                  console.log('Parsed skills:', parsedSkills);
                } catch (error) {
                  console.warn('Error parsing skills JSON:', error.message);
                  parsedSkills = [];
                }
              }

              // Ensure parsedSkills is an array and filter out empty strings
              if (!Array.isArray(parsedSkills)) {
                parsedSkills = [];
              }
              parsedSkills = parsedSkills.filter(skill => skill && skill.trim().length > 0);

              // Insert job seeker profile
              const insertJobSeekerQuery = `
                INSERT INTO job_seekers (userId, title, experience, skills, expectedSalary, linkedinUrl, githubUrl, bio, availability, cvFilePath, certificatesPath) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
              `;
              
              db.query(insertJobSeekerQuery, [
                userId,
                title || null,
                experience || null,
                JSON.stringify(parsedSkills),
                expectedSalary || null,
                linkedinUrl || null,
                githubUrl || null,
                bio || null,
                availability || 'available',
                cvFilePath,
                JSON.stringify(certificatesPath)
              ], async (err) => {
                if (err) {
                  console.error('Job seeker profile insertion error:', err);
                  return res.status(500).json({ 
                    success: false, 
                    msg: 'Server error during registration' 
                  });
                }

                console.log('Job seeker profile created successfully');

                // Generate JWT token
                const token = jwt.sign(
                  { 
                    userId: userId, 
                    email: email, 
                    userType: userType 
                  },
                  process.env.JWT_SECRET || 'your-secret-key',
                  { expiresIn: '24h' }
                );

                // Send welcome email for job seeker (commented out if email service not available)
                try {
                  // Uncomment if you have email service set up
                  // const emailResult = await sendWelcomeEmail(userData, 'jobseeker');
                  // if (emailResult.success) {
                  //   console.log('Welcome email sent to job seeker:', email);
                  // } else {
                  //   console.warn('Failed to send welcome email:', emailResult.error);
                  // }
                } catch (emailError) {
                  console.warn('Email sending error:', emailError.message);
                  // Don't fail registration if email fails
                }

                res.status(201).json({
                  success: true,
                  msg: 'Registration successful!',
                  token,
                  user: {
                    id: userId,
                    userName,
                    email,
                    userType,
                    firstName,
                    lastName
                  }
                });
              });

            } else if (userType === 'recruiter') {
              // Insert recruiter profile
              const insertRecruiterQuery = `
                INSERT INTO recruiters (userId, companyName, companySize, industry, companyWebsite, companyDescription, position) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
              `;
              
              db.query(insertRecruiterQuery, [
                userId,
                companyName,
                companySize || null,
                industry || null,
                companyWebsite || null,
                companyDescription || null,
                position || null
              ], async (err) => {
                if (err) {
                  console.error('Recruiter profile insertion error:', err);
                  return res.status(500).json({ 
                    success: false, 
                    msg: 'Server error during registration' 
                  });
                }

                console.log('Recruiter profile created successfully');

                // Generate JWT token
                const token = jwt.sign(
                  { 
                    userId: userId, 
                    email: email, 
                    userType: userType 
                  },
                  process.env.JWT_SECRET || 'your-secret-key',
                  { expiresIn: '24h' }
                );

                // Send welcome email for recruiter (commented out if email service not available)
                try {
                  // Uncomment if you have email service set up
                  // const emailResult = await sendWelcomeEmail(userData, 'recruiter', companyName);
                  // if (emailResult.success) {
                  //   console.log('Welcome email sent to recruiter:', email);
                  // } else {
                  //   console.warn('Failed to send welcome email:', emailResult.error);
                  // }
                } catch (emailError) {
                  console.warn('Email sending error:', emailError.message);
                  // Don't fail registration if email fails
                }

                res.status(201).json({
                  success: true,
                  msg: 'Registration successful!',
                  token,
                  user: {
                    id: userId,
                    userName,
                    email,
                    userType,
                    firstName,
                    lastName
                  }
                });
              });
            }
          });
      } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ 
          success: false, 
          msg: 'Server error during registration' 
        });
      }
    });

  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ 
      success: false, 
      msg: 'Server error during registration' 
    });
  }
};

// Get user profile
const getUserProfile = (req, res) => {
  const userId = req.user.userId; // From JWT middleware

  const query = 'SELECT id, userName, email, userType, firstName, lastName, phone, location FROM users WHERE id = ?';
  
  db.query(query, [userId], (err, users) => {
    if (err) {
      console.error('Get profile error:', err);
      return res.status(500).json({ 
        success: false, 
        msg: 'Error fetching user profile' 
      });
    }

    if (users.length === 0) {
      return res.status(404).json({ 
        success: false, 
        msg: 'User not found' 
      });
    }

    const user = users[0];

    if (user.userType === 'jobseeker') {
      const profileQuery = 'SELECT * FROM job_seekers WHERE userId = ?';
      
      db.query(profileQuery, [userId], (err, jobSeekers) => {
        if (err) {
          console.error('Job seeker profile error:', err);
          return res.status(500).json({ 
            success: false, 
            msg: 'Error fetching user profile' 
          });
        }

        let profile = null;
        if (jobSeekers.length > 0) {
          try {
            profile = {
              ...jobSeekers[0],
              skills: jobSeekers[0].skills ? JSON.parse(jobSeekers[0].skills) : [],
              certificatesPath: jobSeekers[0].certificatesPath ? JSON.parse(jobSeekers[0].certificatesPath) : []
            };
          } catch (parseError) {
            console.warn('Error parsing JSON fields:', parseError);
            profile = {
              ...jobSeekers[0],
              skills: [],
              certificatesPath: []
            };
          }
        }

        res.json({
          success: true,
          user,
          profile
        });
      });

    } else if (user.userType === 'recruiter') {
      const profileQuery = 'SELECT * FROM recruiters WHERE userId = ?';
      
      db.query(profileQuery, [userId], (err, recruiters) => {
        if (err) {
          console.error('Recruiter profile error:', err);
          return res.status(500).json({ 
            success: false, 
            msg: 'Error fetching user profile' 
          });
        }

        let profile = null;
        if (recruiters.length > 0) {
          profile = recruiters[0];
        }

        res.json({
          success: true,
          user,
          profile
        });
      });
    }
  });
};

// Update user profile
const updateUserProfile = async (req, res) => {
  try {
    const userId = req.user.userId;
    const { 
      firstName, 
      lastName, 
      userName, 
      email, 
      phone, 
      location,
      // Job seeker fields
      title, 
      experience, 
      skills, 
      expectedSalary, 
      linkedinUrl, 
      githubUrl, 
      bio, 
      availability,
      // Recruiter fields
      companyName,
      companySize,
      industry,
      companyWebsite,
      companyDescription,
      position
    } = req.body;

    // Update users table
    const updateUserQuery = `UPDATE users SET firstName = ?, lastName = ?, userName = ?, email = ?, phone = ?, location = ? WHERE id = ?`;
    
    db.query(updateUserQuery, [firstName, lastName, userName, email, phone || null, location || null, userId], (err) => {
      if (err) {
        console.error('User update error:', err);
        return res.status(500).json({ success: false, msg: 'Server error' });
      }

      // Check user type to update appropriate profile
      const getUserTypeQuery = 'SELECT userType FROM users WHERE id = ?';
      db.query(getUserTypeQuery, [userId], (err, users) => {
        if (err) {
          console.error('Get user type error:', err);
          return res.status(500).json({ success: false, msg: 'Server error' });
        }

        if (users.length === 0) {
          return res.status(404).json({ success: false, msg: 'User not found' });
        }

        const userType = users[0].userType;

        if (userType === 'jobseeker') {
          // Parse skills properly for update
          let parsedSkills = [];
          if (skills) {
            try {
              if (typeof skills === 'string') {
                parsedSkills = JSON.parse(skills);
              } else if (Array.isArray(skills)) {
                parsedSkills = skills;
              }
            } catch (error) {
              console.warn('Invalid skills JSON during update');
              parsedSkills = [];
            }
          }

          // Ensure it's an array and filter out empty strings
          if (!Array.isArray(parsedSkills)) {
            parsedSkills = [];
          }
          parsedSkills = parsedSkills.filter(skill => skill && skill.trim().length > 0);

          const updateProfileQuery = `UPDATE job_seekers SET title = ?, experience = ?, skills = ?, expectedSalary = ?, linkedinUrl = ?, githubUrl = ?, bio = ?, availability = ? WHERE userId = ?`;
          
          db.query(updateProfileQuery, [
            title || null, 
            experience || null, 
            JSON.stringify(parsedSkills), 
            expectedSalary || null, 
            linkedinUrl || null, 
            githubUrl || null, 
            bio || null, 
            availability || 'available', 
            userId
          ], (err) => {
            if (err) {
              console.error('Profile update error:', err);
              return res.status(500).json({ success: false, msg: 'Server error' });
            }

            res.json({ success: true, msg: 'Profile updated successfully' });
          });

        } else if (userType === 'recruiter') {
          // Update recruiter profile
          const updateRecruiterQuery = `UPDATE recruiters SET companyName = ?, companySize = ?, industry = ?, companyWebsite = ?, companyDescription = ?, position = ? WHERE userId = ?`;
          
          db.query(updateRecruiterQuery, [
            companyName || null,
            companySize || null,
            industry || null,
            companyWebsite || null,
            companyDescription || null,
            position || null,
            userId
          ], (err) => {
            if (err) {
              console.error('Recruiter profile update error:', err);
              return res.status(500).json({ success: false, msg: 'Server error' });
            }

            res.json({ success: true, msg: 'Profile updated successfully' });
          });
        }
      });
    });
  } catch (error) {
    console.error('Profile update error:', error);
    res.status(500).json({ success: false, msg: 'Server error' });
  }
};

module.exports = {
  registerUser,
  getUserProfile,
  createTables,
  updateUserProfile
};